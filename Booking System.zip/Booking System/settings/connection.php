<?php
$host = 'localhost';
$db_name = 'wt2024';
$name = 'root';
$password = '';

$conn = new mysqli($host, $name, $password, $db_name);

if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}
