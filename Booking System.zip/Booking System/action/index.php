<?php
header("Location: ../Login/login.php");
exit();